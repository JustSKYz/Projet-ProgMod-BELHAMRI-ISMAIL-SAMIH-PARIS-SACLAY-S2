#include <iostream>
#define DOCTEST_CONFIG_IMPLEMENT
#include "doctest.h"
#include "animaux.hpp"
//#include "game.hpp"
#include "constants.hpp"
#include "coords.hpp"

using namespace std;

TEST_CASE("TEST DE LA CLASSE COORD"){

    coords a{12, 5};
    CHECK(a.getX() == 12);
    CHECK(a.getY() == 5);
    a.setX(40);
    a.setY(0);
    cout << a << endl;
    CHECK(a != coords{12, 5});
    CHECK(a == coords{40, 0});

    coords b{485};
    CHECK(b == coords{12, 5});
    CHECK(a.toInt() == 1600);

}

TEST_CASE("TEST DE LA CLASSE POPULATION"){
	
	Population p("MyPopulation");
    int id1 = p.reserve();
    Lapin* a1 = new Lapin(coords {9, 25}, 0.32, &p, id1);
    p.set(a1);
    p.getAnimal(id1)->reproduce();
	p.affichePopulation();
	a1->meurt();
	cout << endl;
    p.affichePopulation();
}

int main(int argc, const char **argv){
    srand(time(NULL));

	doctest::Context context(argc, argv);
    int test_result = context.run();
	if (context.shouldExit()) return test_result;
    
	cout << "FIN DU PROGRAMME" << endl;
    return EXIT_SUCCESS;
}