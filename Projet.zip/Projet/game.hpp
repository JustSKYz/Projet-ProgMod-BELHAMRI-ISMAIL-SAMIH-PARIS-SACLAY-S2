#ifndef GAME
#define GAME

#include <vector>
#include <string>

class Population;

#include "animaux.hpp"
#include "coords.hpp"



class grille {
    public:
        grille() = delete;
        grille(int size, Population *p, double probLapin, double probRenard);
        void afficherTaille() const;
        void spawnRenard();
        void spawnLapin();
        void deleteRenard(int id);
        void deleteLapin(int id);
        void afficheGrille() const;
        coords trouveCoordLibre() const;

    private:
        std::vector<std::vector<std::string>> _grid;
        Population *_p;
};

#endif
