#include <iostream>
#include <vector>


#include "animaux.hpp"
//#include "game.hpp"
#include "constants.hpp"
#include "coords.hpp"


using namespace std;

/*
_________________________________CLASSE ANIMAL____________________________________________

*/

Animal::Animal(coords coord, double probReproduction, Population *p):_id{-1}, _coords{coord}, _probReproduction{probReproduction}, _p {p}
{
    
}

coords Animal::get_coord() const{
    return _coords;
    
}

Population* Animal::getPopulation() const{
    return _p;
    
}

int Animal::get_id() const{
    return _id;
    
}


void Animal::setId(int id){
    _id = id;
	
}

void Animal::meurt(){

    cout << "L'animal " << get_id() << " meurt." << endl;
    getPopulation()->supprime( getPopulation()->getAnimal(get_id()));
	_p = nullptr;
    
}

void Animal::deplacement(direction d){
	
	switch(d){
		case direction::n :
			if(get_coord().getY() - 1 >= 0) _coords.setY(get_coord().getY() - 1);
			break;
		case direction::s :
			if(get_coord().getY() + 1 <= TAILLEGRILLE) _coords.setY(get_coord().getY() + 1);
			break;
		case direction::e :
			if(get_coord().getX() + 1 <= TAILLEGRILLE) _coords.setX(get_coord().getX() + 1);
			break;
		case direction::w :
			if(get_coord().getX() -1 >= 0) _coords.setX(get_coord().getX() - 1);
			break;
		case direction::ne :
			
		case direction::nw :

		case direction::se :
		
		case direction::sw :

		
	}

	
}

/*
_________________________________CLASSE LAPIN_____________________________________________

*/

Lapin::Lapin(coords coord, double probReproduction, Population *p, int id): Animal(coord, probReproduction, p)
{
    setId(id);
}

void Lapin::afficheAnimal() const{
    cout << "Lapin (Id " << get_id() << " )" << endl;
    cout << "Coordonnees : " << get_coord() << endl;
    cout << "Population : " << getPopulation()->get_name() << endl;
}

void Lapin::reproduce() const{
    cout << "Lapin " << get_id() << " essaie de se reproduire." << endl;
    // a completer
    
}


/*
_________________________________CLASSE RENARD____________________________________________

*/

Renard::Renard(coords coord, double probReproduction, Population *p, int id): Animal(coord, probReproduction, p), _hunger{FOODINIT}
{
    setId(id);
}

void Renard::reproduce() const{
     cout << "Renard " << get_id() << " essaie de se reproduire." << endl;
    // a completer
}

void Renard::afficheAnimal() const{
    cout << "Renard (Id " << get_id() << " )" << endl;
    cout << "Coordonnees : " << get_coord() << endl;
    cout << "Population : " << getPopulation()->get_name() << endl;
}


/*
_________________________________CLASSE POPULATION________________________________________

*/



Population::Population(string name):_name{name}, _animaux{} { }

/*
A revoir (systeme d'attribution naif)
*/



int Population::reserve() const{
    
    if (getNbIndividus() == 0) return 1; // id numero 1 si la population est vide
    else{
        int res = _animaux[0]->get_id();
        cout << res << endl;
        for(Animal *i: _animaux) if (res > i->get_id()) res = i->get_id();
        return res + 1;
        
    }
    
}

string Population::get_name() const{
    return _name;
    
}

int Population::getNbIndividus() const{ return _animaux.size();}

int Population::getNbLapins() const{

    int res = 0;
    for(Animal *i: _animaux) if(dynamic_cast<Lapin*>(i)) res++;
    return res;
    
}

int Population::getNbRenards() const{

    int res = 0;
    for(Animal *i: _animaux) if(dynamic_cast<Renard*>(i)) res++;
    return res;
    
}

void Population::set(Animal *a){

    for(Animal *i: _animaux){
        if(i->get_id() == a->get_id()) throw invalid_argument("Cet animal est deja dans la population.");

    }
    if(dynamic_cast<Lapin*>(a)) cout << "Ajoute lapin a la population " << get_name() << endl;
    if(dynamic_cast<Renard*>(a)) cout << "Ajoute renard a la population " << get_name() << endl;
    _animaux.push_back(a);
    
}

void Population::supprime(Animal *a){

    for(int i=0; i<getNbIndividus(); i++){
        if(_animaux[i]->get_id() == a->get_id()){
            Animal *temp = _animaux[i];
            _animaux[i] = _animaux[getNbIndividus() - 1];
            _animaux[getNbIndividus() - 1] = temp;
            _animaux.pop_back();
            delete temp;
            return;
        }
    }
    throw invalid_argument("Cet animal n'est pas dans la population.");
}


Animal* Population::getAnimal(int id) const{
    for(Animal *i: _animaux){
        if(i->get_id() == id){
            return i;
        }
    }
    cout << "Cet animal n'existe pas dans la population." << endl;
    return nullptr;
}


void Population::affichePopulation() const{
    cout << "Population: " << get_name() << endl;
    for(Animal *i: _animaux){
        if(dynamic_cast<Lapin*>(i)){
            cout << "\tLapin (Id " << i->get_id() << " )" << endl;
        }
        if(dynamic_cast<Renard*>(i)){
            cout << "\tRenard (Id " << i->get_id() << " )" << endl;
        }

    }
    
}

Population::~Population(){
    
    for (Animal* a : _animaux) {
            delete a;
        }
    }
    
