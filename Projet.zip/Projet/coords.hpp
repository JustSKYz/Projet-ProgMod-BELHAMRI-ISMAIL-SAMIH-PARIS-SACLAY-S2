#ifndef COORDS
#define COORDS
#include <stdexcept>
#include<sstream>


class coords {
    public:
        coords() = delete;
        coords(int a, int b);
        coords(int n);
        void setX(int X);
        void setY(int Y);
        int toInt() const;
        int getX() const;
        int getY() const;
        bool operator==(const coords &b) const;
        bool operator<(const coords &b) const;
        bool operator!=(const coords &b) const;
        friend std::ostream& operator<<(std::ostream& out, const coords &c);
    private:
        int x;
        int y;
};

#endif