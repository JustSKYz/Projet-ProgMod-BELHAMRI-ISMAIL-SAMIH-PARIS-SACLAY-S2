
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include "game.hpp"
#include "animaux.hpp"
#include "coords.hpp"
#include "constants.hpp"

using namespace std;

bool randomEvent(double prob){
    return rand() % 100 < prob*100;
    
}



grille::grille(int size, Population *p, double probLapin, double probRenard): _grid{vector<vector<string>>(size, vector<string>(size))}, _p{p}
 {
    int randint;
    for(int i=0; i<_grid.size(); i++){
        for(int j=0; j<_grid[i].size(); j++){
            randint = rand() % 100;
            if(randint <= probLapin*100){
                int id = _p->reserve();
                Lapin a(coords {i,j}, PROBREPROLAPIN, _p, id);
                _p->set(a);
                _grid[i][j] = "L";
                
            }
            else if(randint > probLapin*100 && randint <= (probLapin + probRenard)*100){
                int id = _p->reserve();
                Renard a(coords {i,j}, PROBREPRORENARD, _p, id);
                _p->set(a);
                _grid[i][j] = "R";

            }
            else{
                _grid[i][j] = " ";

            }
        }
    }
    
}



/*
    
coords grille::trouveCoordLibre() const{
    int x = rand() % _grid.size();
    int y = rand() % _grid.size();
    
    while(_grid[x][y] != " "){
        x = rand() % _grid.size();
        y = rand() % _grid.size();
    }
    
}
*/