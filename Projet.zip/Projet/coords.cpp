#include<sstream>
#include "coords.hpp"
#include "constants.hpp"
#include <iostream>
#include <stdexcept>
#define DOCTEST_CONFIG_IMPLEMENT
using namespace std;

coords::coords(int a, int b): x{a}, y{b}
{ 
    if(a < 0 || a > TAILLEGRILLE || b < 0 || b > TAILLEGRILLE) throw invalid_argument("Coordonées invalides");

}

coords::coords(int n): coords(n/TAILLEGRILLE, n%TAILLEGRILLE){
    if(n<0) throw invalid_argument("Coordonées invalides");
    
}

void coords::setX(int X){ x = X;}

void coords::setY(int Y){ y = Y;}

int coords::getX() const {return x;}

int coords::getY() const {return y;}

bool coords::operator==(const coords &b) const{
    return (x==b.x && y==b.y);
}

bool coords::operator!=(const coords &b) const{
    return !(*this == b);
}

bool coords::operator<(const coords &b) const{
    if(y>= b.y) return false;
    else if(y== b.y && x>= b.x) return false;
    else return true;
}

int coords::toInt() const{
    return x*TAILLEGRILLE + y;

}

std::ostream& operator<<(std::ostream& out, const coords &c){
    out << "(" << c.x << "," << c.y << ")";
    return out;
    
}
